/********************************************************************************
* main.c: Demonstration av drivrutiner som utg�r kopior av Arduino:s egna
*         funktioner pinMode, digitalWrite, digitalRead samt delay. En lysdiod
*         ansluts till pin 8 och en tryckknapp ansluts till pin 13. Vid
*         nedtryckning av tryckknappen blinkar lysdioden var 100:e, �vrig
*         tid h�lls den sl�ckt.
*
*         Drivrutinerna fungerar identiskt med motsvarande Arduino-funktioner
*         med skillnad att de �r mycket effektivare sett till antalet
*         klockcykler som kr�vs f�r en given instruktion.
********************************************************************************/
#include "gpio.h"

/********************************************************************************
* main: S�tter lysdioden till utport och aktiverar den interna pullup-resistorn
*       p� tryckknappens pin. Vid nedtryckning av tryckknappen blinkar lysdioden
*       var 100:e ms, annars h�lls den sl�ckt.
********************************************************************************/
int main(void)
{
   pinMode(8, OUTPUT);
   pinMode(13, INPUT_PULLUP);

   while (1)
   {
      if (digitalRead(13))
      {
         digitalWrite(8, HIGH);
         delay(100);
         digitalWrite(8, LOW);
         delay(100);
      }
      else
      {
         digitalWrite(8, LOW);
      }
   }
   return 0;
}

