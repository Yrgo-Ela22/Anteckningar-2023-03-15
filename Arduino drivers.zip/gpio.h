/********************************************************************************
* gpio.h: Inneh�ller drivrutiner f�r GPIO-implementering som motsvarar
*         Arduino:s egna rutiner med samma namn.
********************************************************************************/
#ifndef GPIO_H_
#define GPIO_H_

/********************************************************************************
* F_CPU: Definierar klockfrekvensen till 16 MHz f�r f�rdr�jningsrutiner.
********************************************************************************/
#define F_CPU 16000000UL

/********************************************************************************
* Inkluderingsdirektiv:
********************************************************************************/
#include <avr/io.h>     /* Inneh�ller information om I/O-register s�som PORTB. */
#include <util/delay.h> /* Inneh�ller f�rdr�jningsrutiner. */
#include <stdbool.h>    /* Inneh�ller datatypen bool. */

/********************************************************************************
* Makrodefinitioner:
********************************************************************************/
#define LOW  0 /* L�g digital signal. */
#define HIGH 1 /* H�g digital signal. */

#define INPUT        0 /* Inport med inaktiverad intern pullup-resistor. */
#define INPUT_PULLUP 1 /* Inport med aktiverad intern pullup-resistor. */
#define OUTPUT       2 /* Utport. */

/********************************************************************************
* pinMode: Initierar h�rdvara f�r angiven pin utefter specificerat l�ge, som
*          kan v�ljas mellan utport eller inport med eller utan aktivering 
*          av intern pullup-resistor.
*
*          - pin : Digital pin 0 - 13 som ska initieras.
*          - mode: Indikerar vilket l�ga aktuell pin ska initieras i.
********************************************************************************/
static inline void pinMode(const uint8_t pin, 
                           const uint8_t mode)
{
   if (pin >= 0 && pin <= 7)
   {
      if (mode == INPUT_PULLUP)
      {
         PORTD |= (1 << pin);
      }
      else if (mode == OUTPUT)
      {
         DDRD |= (1 << pin);
      }
   }
   else if (pin >= 8 && pin <= 13)
   {
      if (mode == INPUT_PULLUP)
      {
         PORTB |= (1 << (pin - 8));
      }
      else if (mode == OUTPUT)
      {
         DDRB |= (1 << (pin - 8));
      }
   }
   return;
}

/********************************************************************************
* digitalWrite: Skriver ny digital utsignal till specificerad pin. Utsignalen
*               s�tts antingen till l�g eller h�g. Anv�nd f�redragsvis makron
*               LOW respektive HIGH, men �ven 0 respektive 1 fungerar.
*
*               - pin: Digital pin 0 - 13 vars utsignal ska uppdateras.
*               - val: Ny digital utsignal (l�g eller h�g).
********************************************************************************/
static inline void digitalWrite(const uint8_t pin, 
                                const uint8_t val)
{
   if (pin >= 0 && pin <= 7)
   {
      if (val)
      {
         PORTD |= (1 << pin);
      }
      else
      {
         PORTD &= ~(1 << pin);
      }
   }
   else if (pin >= 8 && pin <= 13)
   {
      if (val)
      {
         PORTB |= (1 << (pin - 8));
      }
      else
      {
         PORTB &= ~(1 << (pin - 8));
      }
   }
   return;
}

/********************************************************************************
* digitalRead: Returnerar digital insignal l�st fr�n angiven pin. Vid h�g
*              insignal returneras true (1), annars false (0).
*
*              - pin: Digital pin 0 - 13 vars insignal ska l�sas av.
********************************************************************************/
static inline bool digitalRead(const uint8_t pin)
{
   if (pin >= 0 && pin <= 7)
   {
      return (PIND & (1 << pin));
   }
   else if (pin >= 8 && pin <= 13)
   {
      return (PINB & (1 << (pin - 8)));
   }
   else
   {
      return false;
   }
}

/********************************************************************************
* delay: Genererar f�rdr�jning m�tt i millisekunder.
*
*        - delay_time_ms: F�rdr�jningstid m�tt i millisekunder.
********************************************************************************/
static inline void delay(const uint16_t delay_time_ms)
{
   for (uint16_t i = 0; i < delay_time_ms; ++i)
   {
      _delay_ms(1);
   }
   return;
}

#endif /* GPIO_H_ */